# Prompt Komik

Aplikasi Android pembuat prompt Gemini yang konsisten: tokoh dari foto berlabel, adegan dari naskah PDF, gaya komik 90-an (hitam-putih atau berwarna). Tanpa API, semua gratis.

## Cara build lewat GitHub
1. Buat repository baru di GitHub, unggah semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions**, pilih **Build APK**, tekan **Run workflow** (atau otomatis jalan saat push ke `main`).
3. Setelah selesai (sekitar 3-5 menit), unduh artifact **PromptKomik-apk**, ekstrak, lalu pasang `app-debug.apk` di HP.

## Cara pakai
1. **Tokoh**: tambah foto, isi nama dan peran. Simpan kolase ke galeri, salin perintah lalu buka Gemini, lampirkan kolase, kirim. Tempel jawaban Gemini lalu tekan Urai.
2. **Naskah**: pilih PDF, salin perintah lalu buka Gemini, kirim, tempel jawabannya lalu tekan Urai.
3. **Adegan**: pilih gaya dan rasio, tekan Buat prompt di tiap adegan, lalu Kirim ke Gemini. Lampirkan kolase tokoh dan pakai satu percakapan Gemini yang sama.
