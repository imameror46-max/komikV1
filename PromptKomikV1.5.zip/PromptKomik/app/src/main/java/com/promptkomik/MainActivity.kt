package com.promptkomik

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val reqFile = 1001
    private val reqImages = 2001
    private val reqPdf = 2002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(params.createIntent(), reqFile)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            reqFile -> {
                fileCallback?.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                )
                fileCallback = null
            }
            reqImages -> {
                if (resultCode == RESULT_OK && data != null) {
                    handleImages(data)
                } else {
                    js("onNativeStatus(" + JSONObject.quote("Pemilihan foto dibatalkan (kode $resultCode)") + ")")
                }
            }
            reqPdf -> {
                val pdfUri = data?.data
                if (resultCode == RESULT_OK && pdfUri != null) {
                    handlePdf(pdfUri)
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun handleImages(data: Intent) {
        val uris = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            data.data?.let { uris.add(it) }
        }
        js("onNativeStatus(" + JSONObject.quote("Menerima ${uris.size} foto, memproses...") + ")")
        Thread {
            val arr = JSONArray()
            val errs = StringBuilder()
            for (u in uris) {
                try {
                    val d = decodePhoto(u)
                    if (d != null) {
                        arr.put(JSONObject().put("name", u.lastPathSegment ?: "foto").put("data", d))
                    } else {
                        errs.append("foto tidak bisa dibaca; ")
                    }
                } catch (e: Throwable) {
                    errs.append(e.javaClass.simpleName + ": " + e.message + "; ")
                }
            }
            js("onNativePhotos(" + arr.toString() + "," + JSONObject.quote(errs.toString()) + ")")
        }.start()
    }

    private fun decodePhoto(uri: Uri): String? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longestSide = maxOf(bounds.outWidth, bounds.outHeight)
        while (longestSide / sample > 1280) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null

        val rot: Float = try {
            contentResolver.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }

        val longest = maxOf(bmp.width, bmp.height)
        if (longest > 640) {
            val k = 640f / longest
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * k).toInt().coerceAtLeast(1),
                (bmp.height * k).toInt().coerceAtLeast(1),
                true
            )
        }
        if (rot != 0f) {
            val m = Matrix().apply { postRotate(rot) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 78, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun handlePdf(uri: Uri) {
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    js("onNativePdfError(" + JSONObject.quote("PDF tidak bisa dibuka") + ")")
                } else if (bytes.size > 20 * 1024 * 1024) {
                    js("onNativePdfError(" + JSONObject.quote("PDF terlalu besar (maks 20 MB)") + ")")
                } else {
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    js("onNativePdf(" + JSONObject.quote(uri.lastPathSegment ?: "naskah.pdf") + ",\"" + b64 + "\")")
                }
            } catch (e: Throwable) {
                js("onNativePdfError(" + JSONObject.quote("${e.javaClass.simpleName}: ${e.message}") + ")")
            }
        }.start()
    }

    inner class Bridge {
        private fun setClip(text: String) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("prompt", text))
        }

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface
        fun copy(text: String) {
            setClip(text)
            toast("Prompt disalin")
        }

        @JavascriptInterface
        fun pickImages() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "Pilih foto tokoh"), reqImages)
                } catch (e: Exception) {
                    toast("Tidak bisa membuka pemilih foto: ${e.message}")
                }
            }
        }

        @JavascriptInterface
        fun pickPdf() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "Pilih naskah PDF"), reqPdf)
                } catch (e: Exception) {
                    toast("Tidak bisa membuka pemilih file: ${e.message}")
                }
            }
        }

        @JavascriptInterface
        fun openGemini(text: String) {
            setClip(text)
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Prompt disalin, tempel di Gemini", Toast.LENGTH_LONG).show()
                val i = packageManager.getLaunchIntentForPackage("com.google.android.apps.bard")
                if (i != null) {
                    startActivity(i)
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/app")))
                }
            }
        }

        @JavascriptInterface
        fun saveImage(base64: String, name: String): Boolean {
            return try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PromptKomik")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                true
            } catch (e: Exception) {
                false
            }
        }
    }
}
